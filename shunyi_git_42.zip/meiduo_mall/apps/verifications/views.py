# from random import randint
#
# from django.http import HttpResponse, JsonResponse
# from django.views import View
# from django_redis import get_redis_connection
# from celery_tasks.sms.tasks import celery_send_sms_code
# from libs.captcha.captcha import captcha
# # from libs.yuntongxun.sms import CCP
#
#
# # Create your views here.
# class ImageCodeView(View):
#     def get(self, request, uuid):
#         text, image = captcha.generate_captcha()
#         redis_cli = get_redis_connection('code')
#         redis_cli.setex(uuid, 100, text)
#         return HttpResponse(image, content_type='image/jpeg')
#
#
# ####### 绑定视图 ######
# class SmsCodeView(View):
#     def get(self, request, mobile):
#         # 1. 获取请求参数
#         image_code = request.GET.get('image_code')
#         uuid = request.GET.get('image_code_id')
#
#         # 2. 校验参数
#         if not all([image_code, uuid]):
#             return JsonResponse({'code': 400, 'errmsg': '缺少必传参数'})
#
#         # 3. 创建连接到redis的对象
#         redis_cli = get_redis_connection('code')
#         redis_image_code = redis_cli.get(uuid)
#
#         # 4. 判断验证码是否过期
#         if redis_image_code is None:
#             return JsonResponse({'code': 400, 'errmsg': '图片验证码失效'})
#
#         # 对比
#         if redis_image_code.decode().lower() != image_code.lower():
#             return JsonResponse({'code': 400, 'errmsg': '图片验证码错误'})
#
#         # 5. 生成短信验证码
#         sms_code = '%06d' % randint(0, 999999)
#
#         # 打印查看 mobile 和 sms_code 的值
#         print(f"mobile: {mobile}, sms_code: {sms_code}")
#
#         # 6. 管道操作，保存验证码到 redis
#         pipeline = redis_cli.pipeline()
#         pipeline.setex(mobile, 300, sms_code)  # 设置短信验证码 5分钟过期
#         pipeline.setex('send_flag_%s' % mobile, 60, 1)  # 设置发送标记 1分钟过期
#         pipeline.execute()
#
#         # 7. 发送短信验证码
#         print(f"Sending SMS to {mobile} with code {sms_code}")
#         celery_send_sms_code.delay(mobile, sms_code)  # 调用 Celery 任务异步发送短信
#
#         # 8. 返回响应
#         return JsonResponse({'code': 0, 'errmsg': '发送短信成功'})
#上面的版本是用celery异步发送版本，下面是同步发送版本：
from random import randint

from django.http import HttpResponse, JsonResponse
from django.views import View
from django_redis import get_redis_connection
# from celery_tasks.sms.tasks import celery_send_sms_code  # 原来的 Celery 导入
from libs.captcha.captcha import captcha
from libs.yuntongxun.sms import CCP


# from libs.yuntongxun.sms import CCP  # 假设是同步短信发送的模块


# Create your views here.
class ImageCodeView(View):
    def get(self, request, uuid):
        text, image = captcha.generate_captcha()
        redis_cli = get_redis_connection('code')
        redis_cli.setex(uuid, 100, text)
        return HttpResponse(image, content_type='image/jpeg')


####### 绑定视图 ######
class SmsCodeView(View):
    def get(self, request, mobile):
        # 1. 获取请求参数
        image_code = request.GET.get('image_code')
        uuid = request.GET.get('image_code_id')

        # 2. 校验参数
        if not all([image_code, uuid]):
            return JsonResponse({'code': 400, 'errmsg': '缺少必传参数'})

        # 3. 创建连接到redis的对象
        redis_cli = get_redis_connection('code')
        redis_image_code = redis_cli.get(uuid)

        # 4. 判断验证码是否过期
        if redis_image_code is None:
            return JsonResponse({'code': 400, 'errmsg': '图片验证码失效'})

        # 对比
        if redis_image_code.decode().lower() != image_code.lower():
            return JsonResponse({'code': 400, 'errmsg': '图片验证码错误'})

        # 5. 生成短信验证码
        sms_code = '%04d' % randint(0, 9999)

        # 打印查看 mobile 和 sms_code 的值
        print(f"mobile: {mobile}, sms_code: {sms_code}")

        # 6. 管道操作，保存验证码到 redis
        pipeline = redis_cli.pipeline()
        pipeline.setex(mobile, 300, sms_code)  # 设置短信验证码 5分钟过期
        pipeline.setex('send_flag_%s' % mobile, 60, 1)  # 设置发送标记 1分钟过期
        pipeline.execute()

        # 7. 发送短信验证码（同步方式）
        print(f"Sending SMS to {mobile} with code {sms_code}")
        # 注释掉原来使用 Celery 发送短信的代码
        # celery_send_sms_code.delay(mobile, sms_code)  # 原来使用 Celery 发送短信验证码

        # 使用同步的短信服务发送
        CCP().send_template_sms(mobile, [sms_code, 4], 1)  # 假设这是同步的短信发送方式
        # 这里假设你已经配置了同步短信发送的方式

        # 8. 返回响应
        return JsonResponse({'code': 0, 'errmsg': '发送短信成功'})
