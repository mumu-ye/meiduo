from django.core.cache import cache

from django.http import JsonResponse
from django.views import View
from apps.areas.models import Area


# Create your views here.
# 省级行政区查询
class AreaView(View):
    def get(self, request):
        # 先查询缓存数据
        province_list = cache.get('province')
        if province_list is None:
            # 缓存中没有数据，查询数据库
            # 查询所有省级行政区
            provinces = Area.objects.filter(parent=None)
            # 转换为字典列表
            province_list = []
            for province in provinces:
                province_list.append({
                    'id': province.id,
                    'name': province.name
                })
            # 保存数据到redis中
            cache.set('province', province_list, 24 * 3600)
        # 返回省级行政区列表
        return JsonResponse({'code': 0, 'errmsg': 'ok', 'province_list': province_list})


# 根据省份id查询市,县级行政区
class SubAreaView(View):
    def get(self, request, id):
        # 先查询缓存数据
        data_list = cache.get('city:%s' % id)
        if data_list is None:
            # 缓存中没有数据，查询数据库
            # 查询市级行政区
            up_level = Area.objects.get(id=id)
            down_level = up_level.subs.all()
            # 转换为字典列表
            data_list = []
            for item in down_level:
                data_list.append({
                    'id': item.id,
                    'name': item.name
                })
            cache.set('city:%s' % id, data_list, 24 * 3600)
        # 返回市级行政区列表
        return JsonResponse({'code': 0, 'errmsg': 'ok', 'sub_data': {'subs': data_list}})
