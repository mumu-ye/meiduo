#!/bin/bash
mysql -uroot -p123456 meiduo_mall < goods_data.sql