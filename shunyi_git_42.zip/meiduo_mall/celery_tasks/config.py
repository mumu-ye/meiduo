# 配置信息 key-value 形式存储在redis中 就是所谓的broker
broker_url = "redis://127.0.0.1:6379/15"
