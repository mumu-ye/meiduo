import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'meiduo_mall.settings')

from celery import Celery

app = Celery('celery_tasks')
# 设置broker
app.config_from_object('celery_tasks.config')
# 需要celery自动检测任务，并添加到broker中
app.autodiscover_tasks(['celery_tasks.sms', 'celery_tasks.email'])
# 启动指令为：celery -A celery_tasks worker -l INFO
