# 生产者 -- 任务，函数
# 1. 这个函数 必须要让celery的实例的 task装饰器 装饰
# 2. 需要celery 自动检测指定包的任务
# celery_tasks/sms/tasks.py

from celery_tasks.main import app
from libs.yuntongxun.sms import CCP

@app.task
def celery_send_sms_code(mobile, code):
    # 打印收到的参数，确认是否正确传递
    print(f"Celery task received: mobile={mobile}, code={code}")

    try:
        CCP().send_template_sms(mobile, [code, 5], 1)
        print(f"Successfully sent SMS to {mobile}")
    except Exception as e:
        print(f"Error sending SMS: {e}")


